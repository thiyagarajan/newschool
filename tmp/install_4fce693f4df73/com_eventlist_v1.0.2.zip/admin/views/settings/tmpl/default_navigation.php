<div class="submenu-box">
	<div class="submenu-pad">
		<ul id="submenu">
			<li><a id="basic" class="active"><?php echo JText::_( 'COM_EVENTLIST_BASIC_SETTINGS' ); ?></a></li>
			<li><a id="usercontrol"><?php echo JText::_( 'COM_EVENTLIST_USER_CONTROL' ); ?></a></li>
			<li><a id="details"><?php echo JText::_( 'COM_EVENTLIST_DETAILS_PAGE' ); ?></a></li>
			<li><a id="layout"><?php echo JText::_( 'COM_EVENTLIST_LAYOUT' ); ?></a></li>
			<li><a id="parameters"><?php echo JText::_( 'COM_EVENTLIST_GLOBAL_PARAMETERS' ); ?></a></li>
		</ul>
		<div class="clr"></div>
	</div>
</div>
<div class="clr"></div>
